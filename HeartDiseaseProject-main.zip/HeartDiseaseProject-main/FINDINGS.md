# Heart Disease Prediction Project - Key Findings

## Executive Summary

This project investigated whether heart disease prediction models perform worse for younger patients compared to older patients. The analysis used a synthetic dataset similar to the CDC BRFSS dataset with 10,000 samples and implemented four machine learning models: Logistic Regression, Random Forest, XGBoost, and SVM.

## Key Findings

### 1. Models Predict Heart Disease Unequally Across Age Groups

**Baseline Model Performance (False Negative Rate by Age Group):**

| Age Group | Logistic Regression | Random Forest | XGBoost | SVM |
|-----------|-------------------|---------------|---------|-----|
| Under 40  | 1.00 (100%)       | 1.00 (100%)   | 1.00 (100%) | 1.00 (100%) |
| 40-55     | 0.96              | 0.60          | 0.60    | 0.75 |
| Over 55   | 0.39              | 0.50          | 0.53    | 0.61 |

**Key Observation:** All four models completely fail to identify heart disease in the Under 40 age group (100% False Negative Rate), meaning they miss every single case of heart disease in younger patients.

### 2. Younger Individuals Are Systematically Misclassified as Low Risk

The data clearly shows that younger patients (Under 40) are:
- **Never correctly identified** as having heart disease by baseline models
- **Significantly underdiagnosed** compared to older age groups
- At risk of **delayed diagnosis and treatment**

This is particularly concerning because:
- Young adults with heart disease need early intervention
- The models show high overall accuracy (58-59%) but completely fail for this subgroup
- Relying on overall metrics would mask this critical failure

### 3. Bias Mitigation Techniques Show Improvement

**Impact of Class Reweighting:**

After applying balanced class weights to address class imbalance:

| Model | Age Group | Baseline FNR | Weighted FNR | Improvement |
|-------|-----------|--------------|--------------|-------------|
| Random Forest | Under 40 | 1.00 | 1.00 | 0.00 |
| Random Forest | 40-55 | 0.60 | 0.35 | 0.25 ↓ |
| Random Forest | Over 55 | 0.50 | 0.11 | 0.39 ↓ |
| XGBoost | Under 40 | 1.00 | 0.96 | 0.04 ↓ |
| XGBoost | 40-55 | 0.60 | 0.30 | 0.30 ↓ |
| XGBoost | Over 55 | 0.53 | 0.20 | 0.33 ↓ |

**Key Observations:**
- Class reweighting substantially reduces FNR for the 40-55 and Over 55 groups
- XGBoost shows slight improvement for Under 40 group (96% FNR vs 100%)
- The technique provides better recall for older age groups but minimal improvement for the youngest group
- Overall accuracy decreases slightly (from 59% to 58%) but this is acceptable for better coverage

### 4. The Under 40 Group Remains Challenging

Despite bias mitigation efforts, the Under 40 age group remains extremely difficult to predict accurately. Possible reasons:

1. **Small sample size:** Only 237 test samples (12% of test set)
2. **Low base rate:** Very few heart disease cases in this age group
3. **Different risk patterns:** Younger patients may have different disease presentations
4. **Data imbalance:** The model was trained on data dominated by older patients

## Recommendations

### For Model Development:
1. **Collect more data** from younger patients to improve model training
2. **Use age-specific models** or ensemble approaches that treat age groups separately
3. **Apply advanced bias mitigation** techniques like threshold optimization per age group
4. **Consider oversampling** younger patients or synthetic data generation

### For Clinical Use:
1. **Do not rely solely on model predictions** for younger patients
2. **Apply additional screening** for high-risk younger individuals
3. **Consider model outputs as one factor** among many in clinical decision-making
4. **Monitor false negative rates** by age group in deployment

### For Evaluation:
1. **Always perform subgroup analysis** - don't rely only on overall metrics
2. **Report metrics by demographic groups** to identify biases
3. **Prioritize recall/FNR** over accuracy in medical applications where false negatives are costly
4. **Consider fairness metrics** like demographic parity or equalized odds

## Answers to Research Questions

**Q1: Do machine learning models predict heart disease equally well for all age groups?**
- **No.** All models show dramatically worse performance for younger patients, with 100% FNR in the Under 40 group.

**Q2: Are younger individuals more likely to be misclassified as low risk?**
- **Yes.** Younger patients are systematically classified as low risk, missing all heart disease cases in the baseline models.

**Q3: Can simple adjustments improve model performance for younger patients?**
- **Partially.** Class reweighting substantially helps the 40-55 and Over 55 groups but provides minimal improvement for the Under 40 group. More sophisticated approaches are needed.

## Project Importance

This project demonstrates a critical issue in medical machine learning: **overall accuracy can be misleading**. A model with 59% accuracy might seem marginally useful, but when it has a 100% false negative rate for an entire demographic group, it becomes dangerous.

Heart disease in younger individuals is already often overlooked. If machine learning models also fail to identify risk in this group, it could lead to:
- Delayed diagnosis
- Missed early intervention opportunities
- Health disparities
- Loss of trust in AI-assisted healthcare

## Conclusion

This analysis confirms that heart disease prediction models perform significantly worse for younger patients. While bias mitigation techniques like class reweighting can help, the challenge of predicting rare events in underrepresented groups remains. **Subgroup analysis is essential** - we must look beyond overall accuracy to ensure models work fairly across all demographics.

## Files Generated

The complete analysis generated:
- **40 visualization files** (confusion matrices, ROC curves, FNR comparisons)
- **8 detailed reports** (baseline and weighted for each model)
- **8 age group comparison CSV files**
- **1 summary comparison** across all models and methods

All files are available in the `results/` directory.

## Next Steps

1. Test with real BRFSS data (400,000+ samples)
2. Implement threshold optimization per age group
3. Explore age-specific feature engineering
4. Develop ensemble models with age-aware weighting
5. Validate findings with clinical experts
