# Quick Start Guide

## Getting Started in 5 Minutes

### Step 1: Clone and Install

```bash
git clone https://github.com/harshgagneja/HeartDiseaseProject.git
cd HeartDiseaseProject
pip install -r requirements.txt
```

### Step 2: Verify Installation

```bash
python test_pipeline.py
```

You should see:
```
✓ All tests passed! The pipeline is ready to use.
```

### Step 3: Generate Sample Data (if needed)

```bash
python generate_sample_data.py
```

This creates `data/heart_disease_sample.csv` with 10,000 synthetic samples.

### Step 4: Run the Analysis

```bash
python pipeline.py --data data/heart_disease_sample.csv --output results
```

This will:
- Train 4 ML models (Logistic Regression, Random Forest, XGBoost, SVM)
- Evaluate performance overall and by age group
- Apply bias mitigation (class reweighting)
- Generate visualizations and reports
- Takes ~2-3 minutes to complete

### Step 5: View Results

Check the `results/` directory:
- **Summary:** `summary_comparison.csv`
- **Reports:** `*_report.txt` files
- **Visualizations:** `*.png` files

Key findings:
```bash
cat results/Random_Forest_baseline_report.txt
```

### Step 6: Interactive Analysis (Optional)

```bash
cd notebooks
jupyter notebook heart_disease_analysis.ipynb
```

## Understanding the Output

### Key Metrics

- **Accuracy:** Overall correctness (can be misleading!)
- **Recall:** Proportion of actual disease cases correctly identified
- **False Negative Rate (FNR):** Proportion of disease cases missed (critical!)
- **AUC-ROC:** Area under ROC curve (model discrimination ability)

### What to Look For

1. **Age Group Bias:** Compare FNR across age groups
   - Higher FNR for "Under 40" = worse performance for younger patients

2. **Bias Mitigation Impact:** Compare baseline vs weighted models
   - Lower FNR after weighting = improvement

3. **Trade-offs:** Check if overall accuracy decreases when improving FNR
   - Acceptable trade-off for medical applications

## Common Tasks

### Use Your Own Data

Your CSV file must have:
- An age column (numeric)
- A target column (binary: 0/1)
- Health-related features

```bash
python pipeline.py --data path/to/your_data.csv --output my_results
```

### Change Random Seed

```bash
python pipeline.py --data data/heart_disease_sample.csv --output results --seed 123
```

### Modify Age Groups

Edit `src/data_preprocessing.py`, function `create_age_groups()`:

```python
def categorize_age(age):
    if age < 35:
        return 'Under 35'
    elif age <= 60:
        return '35-60'
    else:
        return 'Over 60'
```

### Add More Models

Edit `src/model_training.py` and add your model training function, then update `train_all_models()`.

## Troubleshooting

### Import Errors

```bash
pip install --upgrade -r requirements.txt
```

### Memory Issues

Reduce the dataset size or use a subset:

```python
import pandas as pd
df = pd.read_csv('data/heart_disease_sample.csv')
df_subset = df.sample(5000, random_state=42)
df_subset.to_csv('data/subset.csv', index=False)
```

Then run:
```bash
python pipeline.py --data data/subset.csv --output results
```

### Visualization Issues

If running on a server without display, set matplotlib backend:

```python
import matplotlib
matplotlib.use('Agg')
```

## Next Steps

1. **Read FINDINGS.md** for detailed analysis results
2. **Explore the notebook** for interactive analysis
3. **Try real data** (e.g., actual BRFSS dataset)
4. **Customize the pipeline** for your use case

## Questions?

- Check README.md for full documentation
- Review FINDINGS.md for key results
- Open an issue on GitHub for problems

## Tips

- Always run `test_pipeline.py` after making changes
- Use version control to track experiments
- Document your findings in the notebook
- Share results with domain experts for validation

Happy analyzing! 🎉
