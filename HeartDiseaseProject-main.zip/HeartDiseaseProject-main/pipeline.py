"""
Main pipeline for Heart Disease Prediction Project.
"""

import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from data_preprocessing import preprocess_pipeline
from model_training import train_all_models, adjust_threshold
from evaluation import (
    evaluate_model, evaluate_by_age_group, create_comparison_dataframe,
    plot_confusion_matrix, plot_age_group_comparison, plot_roc_curve,
    generate_report
)


def run_pipeline(data_path, output_dir='results', random_state=42):
    """
    Run the complete heart disease prediction pipeline.
    
    Args:
        data_path: Path to the input CSV file
        output_dir: Directory to save results
        random_state: Random seed for reproducibility
    """
    print("="*60)
    print("Heart Disease Prediction Pipeline")
    print("="*60)
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Step 1: Data Preprocessing
    print("Step 1: Data Preprocessing")
    print("-" * 60)
    
    data = preprocess_pipeline(
        filepath=data_path,
        target_column='HeartDisease',
        age_column='Age',
        test_size=0.2,
        random_state=random_state,
        scale=True
    )
    
    X_train = data['X_train']
    X_test = data['X_test']
    y_train = data['y_train']
    y_test = data['y_test']
    age_groups_train = data['age_groups_train']
    age_groups_test = data['age_groups_test']
    
    print(f"Training set size: {len(X_train)}")
    print(f"Test set size: {len(X_test)}")
    print(f"Number of features: {len(data['feature_names'])}")
    print(f"Class distribution (train): {y_train.value_counts().to_dict()}")
    print(f"Age group distribution (test): {age_groups_test.value_counts().to_dict()}\n")
    
    # Step 2: Train Models (Baseline - No Class Weighting)
    print("Step 2: Training Models (Baseline)")
    print("-" * 60)
    
    baseline_models = train_all_models(
        X_train, y_train,
        class_weight=None,
        random_state=random_state
    )
    print("Baseline models trained successfully.\n")
    
    # Step 3: Evaluate Baseline Models
    print("Step 3: Evaluating Baseline Models")
    print("-" * 60)
    
    baseline_results = {}
    for model_name, model in baseline_models.items():
        print(f"\nEvaluating {model_name}...")
        
        # Overall evaluation
        overall_eval = evaluate_model(model, X_test, y_test)
        
        # Age group evaluation
        age_group_eval = evaluate_by_age_group(model, X_test, y_test, age_groups_test)
        
        baseline_results[model_name] = {
            'model': model,
            'overall': overall_eval,
            'by_age_group': age_group_eval
        }
        
        # Generate report
        report = generate_report(
            model_name,
            overall_eval['metrics'],
            age_group_eval
        )
        print(report)
        
        # Save report
        report_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_baseline_report.txt')
        with open(report_path, 'w') as f:
            f.write(report)
        
        # Save confusion matrix
        cm_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_baseline_cm.png')
        plot_confusion_matrix(
            y_test,
            overall_eval['y_pred'],
            title=f'{model_name} - Confusion Matrix (Baseline)',
            save_path=cm_path
        )
        
        # Save age group comparison
        comparison_df = create_comparison_dataframe(age_group_eval)
        csv_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_baseline_age_comparison.csv')
        comparison_df.to_csv(csv_path, index=False)
        
        # Plot FNR by age group
        fnr_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_baseline_fnr_by_age.png')
        plot_age_group_comparison(
            comparison_df,
            metric='false_negative_rate',
            title=f'{model_name} - False Negative Rate by Age Group (Baseline)',
            save_path=fnr_path
        )
        
        # Plot ROC curve if available
        if overall_eval['y_proba'] is not None:
            roc_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_baseline_roc.png')
            plot_roc_curve(
                y_test,
                overall_eval['y_proba'],
                title=f'{model_name} - ROC Curve (Baseline)',
                save_path=roc_path
            )
    
    # Step 4: Train Models with Class Reweighting
    print("\nStep 4: Training Models with Class Reweighting")
    print("-" * 60)
    
    weighted_models = train_all_models(
        X_train, y_train,
        class_weight='balanced',
        random_state=random_state
    )
    print("Weighted models trained successfully.\n")
    
    # Step 5: Evaluate Weighted Models
    print("Step 5: Evaluating Weighted Models")
    print("-" * 60)
    
    weighted_results = {}
    for model_name, model in weighted_models.items():
        print(f"\nEvaluating {model_name} (Weighted)...")
        
        # Overall evaluation
        overall_eval = evaluate_model(model, X_test, y_test)
        
        # Age group evaluation
        age_group_eval = evaluate_by_age_group(model, X_test, y_test, age_groups_test)
        
        weighted_results[model_name] = {
            'model': model,
            'overall': overall_eval,
            'by_age_group': age_group_eval
        }
        
        # Generate report
        report = generate_report(
            f"{model_name} (Weighted)",
            overall_eval['metrics'],
            age_group_eval
        )
        print(report)
        
        # Save report
        report_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_weighted_report.txt')
        with open(report_path, 'w') as f:
            f.write(report)
        
        # Save confusion matrix
        cm_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_weighted_cm.png')
        plot_confusion_matrix(
            y_test,
            overall_eval['y_pred'],
            title=f'{model_name} - Confusion Matrix (Weighted)',
            save_path=cm_path
        )
        
        # Save age group comparison
        comparison_df = create_comparison_dataframe(age_group_eval)
        csv_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_weighted_age_comparison.csv')
        comparison_df.to_csv(csv_path, index=False)
        
        # Plot FNR by age group
        fnr_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_weighted_fnr_by_age.png')
        plot_age_group_comparison(
            comparison_df,
            metric='false_negative_rate',
            title=f'{model_name} - False Negative Rate by Age Group (Weighted)',
            save_path=fnr_path
        )
        
        # Plot ROC curve if available
        if overall_eval['y_proba'] is not None:
            roc_path = os.path.join(output_dir, f'{model_name.replace(" ", "_")}_weighted_roc.png')
            plot_roc_curve(
                y_test,
                overall_eval['y_proba'],
                title=f'{model_name} - ROC Curve (Weighted)',
                save_path=roc_path
            )
    
    # Step 6: Summary Comparison
    print("\nStep 6: Summary Comparison")
    print("-" * 60)
    
    summary_rows = []
    
    for model_name in baseline_models.keys():
        # Baseline
        baseline_overall = baseline_results[model_name]['overall']['metrics']
        baseline_age_groups = baseline_results[model_name]['by_age_group']
        
        for age_group in ['Under 40', '40-55', 'Over 55']:
            if age_group in baseline_age_groups:
                summary_rows.append({
                    'Model': model_name,
                    'Method': 'Baseline',
                    'Age Group': age_group,
                    'Accuracy': baseline_age_groups[age_group]['accuracy'],
                    'Recall': baseline_age_groups[age_group]['recall'],
                    'FNR': baseline_age_groups[age_group]['false_negative_rate']
                })
        
        # Weighted
        weighted_overall = weighted_results[model_name]['overall']['metrics']
        weighted_age_groups = weighted_results[model_name]['by_age_group']
        
        for age_group in ['Under 40', '40-55', 'Over 55']:
            if age_group in weighted_age_groups:
                summary_rows.append({
                    'Model': model_name,
                    'Method': 'Weighted',
                    'Age Group': age_group,
                    'Accuracy': weighted_age_groups[age_group]['accuracy'],
                    'Recall': weighted_age_groups[age_group]['recall'],
                    'FNR': weighted_age_groups[age_group]['false_negative_rate']
                })
    
    summary_df = pd.DataFrame(summary_rows)
    summary_path = os.path.join(output_dir, 'summary_comparison.csv')
    summary_df.to_csv(summary_path, index=False)
    
    print("\nSummary Comparison (False Negative Rate by Age Group):")
    print(summary_df.pivot_table(
        index=['Model', 'Age Group'],
        columns='Method',
        values='FNR'
    ))
    
    print(f"\n{'='*60}")
    print(f"Pipeline completed successfully!")
    print(f"Results saved to: {output_dir}")
    print(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Heart Disease Prediction Pipeline')
    parser.add_argument('--data', type=str, required=True,
                       help='Path to the input CSV file')
    parser.add_argument('--output', type=str, default='results',
                       help='Directory to save results (default: results)')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed (default: 42)')
    
    args = parser.parse_args()
    
    run_pipeline(args.data, args.output, args.seed)
