#!/usr/bin/env python3
"""
Test script to verify the Heart Disease Prediction pipeline works correctly.
"""

import sys
import os

def test_imports():
    """Test that all required modules can be imported."""
    print("Testing imports...")
    try:
        import pandas as pd
        import numpy as np
        import sklearn
        import xgboost
        import matplotlib
        import seaborn
        print("  ✓ All dependencies imported successfully")
        return True
    except ImportError as e:
        print(f"  ✗ Import error: {e}")
        return False

def test_data_exists():
    """Test that sample data exists."""
    print("\nTesting data availability...")
    data_path = 'data/heart_disease_sample.csv'
    if os.path.exists(data_path):
        import pandas as pd
        df = pd.read_csv(data_path)
        print(f"  ✓ Sample data found: {len(df)} rows, {len(df.columns)} columns")
        return True
    else:
        print(f"  ✗ Sample data not found at {data_path}")
        return False

def test_preprocessing():
    """Test data preprocessing pipeline."""
    print("\nTesting preprocessing pipeline...")
    try:
        sys.path.insert(0, 'src')
        from data_preprocessing import preprocess_pipeline
        
        data = preprocess_pipeline(
            filepath='data/heart_disease_sample.csv',
            target_column='HeartDisease',
            age_column='Age',
            test_size=0.2,
            random_state=42,
            scale=True
        )
        
        print(f"  ✓ Preprocessing successful")
        print(f"    - Training samples: {len(data['X_train'])}")
        print(f"    - Test samples: {len(data['X_test'])}")
        print(f"    - Features: {len(data['feature_names'])}")
        return True
    except Exception as e:
        print(f"  ✗ Preprocessing error: {e}")
        return False

def test_model_training():
    """Test model training."""
    print("\nTesting model training...")
    try:
        sys.path.insert(0, 'src')
        from data_preprocessing import preprocess_pipeline
        from model_training import train_logistic_regression
        
        data = preprocess_pipeline(
            filepath='data/heart_disease_sample.csv',
            target_column='HeartDisease',
            age_column='Age',
            test_size=0.2,
            random_state=42,
            scale=True
        )
        
        model = train_logistic_regression(
            data['X_train'], 
            data['y_train'], 
            random_state=42
        )
        
        print(f"  ✓ Model training successful")
        return True
    except Exception as e:
        print(f"  ✗ Model training error: {e}")
        return False

def test_evaluation():
    """Test model evaluation."""
    print("\nTesting model evaluation...")
    try:
        sys.path.insert(0, 'src')
        from data_preprocessing import preprocess_pipeline
        from model_training import train_logistic_regression
        from evaluation import evaluate_model, evaluate_by_age_group
        
        data = preprocess_pipeline(
            filepath='data/heart_disease_sample.csv',
            target_column='HeartDisease',
            age_column='Age',
            test_size=0.2,
            random_state=42,
            scale=True
        )
        
        model = train_logistic_regression(
            data['X_train'], 
            data['y_train'], 
            random_state=42
        )
        
        # Overall evaluation
        overall_eval = evaluate_model(model, data['X_test'], data['y_test'])
        
        # Age group evaluation
        age_eval = evaluate_by_age_group(
            model, 
            data['X_test'], 
            data['y_test'], 
            data['age_groups_test']
        )
        
        print(f"  ✓ Evaluation successful")
        print(f"    - Overall accuracy: {overall_eval['metrics']['accuracy']:.4f}")
        print(f"    - Age groups analyzed: {len(age_eval)}")
        return True
    except Exception as e:
        print(f"  ✗ Evaluation error: {e}")
        return False

def main():
    """Run all tests."""
    print("="*60)
    print("Heart Disease Prediction Pipeline - Test Suite")
    print("="*60)
    
    tests = [
        test_imports,
        test_data_exists,
        test_preprocessing,
        test_model_training,
        test_evaluation
    ]
    
    results = []
    for test in tests:
        try:
            results.append(test())
        except Exception as e:
            print(f"  ✗ Unexpected error: {e}")
            results.append(False)
    
    print("\n" + "="*60)
    print(f"Test Results: {sum(results)}/{len(results)} passed")
    print("="*60)
    
    if all(results):
        print("✓ All tests passed! The pipeline is ready to use.")
        return 0
    else:
        print("✗ Some tests failed. Please check the errors above.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
