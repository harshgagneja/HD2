"""
Download and process the CDC BRFSS 2024 dataset for use with the
Heart Disease Prediction project.

Usage
-----
    python fetch_brfss_data.py

The script will:
  1. Download the BRFSS 2024 combined landline + cell XPT file from the CDC
     (~200 MB compressed).
  2. Extract the XPT file from the ZIP archive.
  3. Map the raw BRFSS variables to the project's column format.
  4. Save the processed dataset to ``data/brfss_2024.csv``.

The resulting CSV can then be used directly with the main pipeline:

    python pipeline.py --data data/brfss_2024.csv --output results
"""

import os
import sys
import zipfile
import urllib.request

import pandas as pd

# Ensure src/ is on the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from brfss_processor import load_brfss_xpt, process_brfss

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BRFSS_2024_URL = (
    "https://www.cdc.gov/brfss/annual_data/2024/files/LLCP2024XPT.zip"
)
DOWNLOAD_DIR = "data"
ZIP_FILENAME = "LLCP2024XPT.zip"
XPT_FILENAME = "LLCP2024.XPT"
OUTPUT_CSV = os.path.join(DOWNLOAD_DIR, "brfss_2024.csv")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _reporthook(block_num, block_size, total_size):
    """Simple progress callback for urllib.request.urlretrieve."""
    downloaded = block_num * block_size
    if total_size > 0:
        pct = min(downloaded * 100 / total_size, 100)
        mb_done = downloaded / 1_048_576
        mb_total = total_size / 1_048_576
        print(
            f"\r  Downloading … {mb_done:.1f} / {mb_total:.1f} MB  ({pct:.0f}%)",
            end="",
            flush=True,
        )
    else:
        print(f"\r  Downloaded {downloaded / 1_048_576:.1f} MB", end="", flush=True)


def download_brfss_zip(url, dest_dir):
    """
    Download the BRFSS ZIP archive to ``dest_dir``.

    Args:
        url: Download URL.
        dest_dir: Directory where the ZIP will be saved.

    Returns:
        Full path to the downloaded ZIP file.
    """
    os.makedirs(dest_dir, exist_ok=True)
    zip_path = os.path.join(dest_dir, ZIP_FILENAME)

    if os.path.exists(zip_path):
        print(f"ZIP already present at {zip_path} — skipping download.")
        return zip_path

    print(f"Downloading BRFSS 2024 data from:\n  {url}")
    urllib.request.urlretrieve(url, zip_path, reporthook=_reporthook)
    print()  # newline after progress
    print(f"Saved to: {zip_path}")
    return zip_path


def extract_xpt(zip_path, dest_dir):
    """
    Extract the XPT file from the ZIP archive.

    Args:
        zip_path: Path to the downloaded ZIP file.
        dest_dir: Directory where the XPT file will be extracted.

    Returns:
        Full path to the extracted XPT file.
    """
    xpt_path = os.path.join(dest_dir, XPT_FILENAME)

    if os.path.exists(xpt_path):
        print(f"XPT already extracted at {xpt_path} — skipping extraction.")
        return xpt_path

    print(f"Extracting {XPT_FILENAME} …")
    with zipfile.ZipFile(zip_path, 'r') as zf:
        # The XPT entry name inside the ZIP may differ in case
        members = zf.namelist()
        match = next(
            (m for m in members if m.upper() == XPT_FILENAME.upper()), None
        )
        if match is None:
            raise FileNotFoundError(
                f"Could not find {XPT_FILENAME} inside {zip_path}. "
                f"Archive contains: {members}"
            )
        zf.extract(match, dest_dir)
        # Rename to the expected name if case differs
        extracted = os.path.join(dest_dir, match)
        if extracted != xpt_path:
            os.rename(extracted, xpt_path)

    print(f"Extracted to: {xpt_path}")
    return xpt_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    print("=" * 60)
    print("BRFSS 2024 Data Download & Processing")
    print("=" * 60)

    # Step 1 – Download
    zip_path = download_brfss_zip(BRFSS_2024_URL, DOWNLOAD_DIR)

    # Step 2 – Extract
    xpt_path = extract_xpt(zip_path, DOWNLOAD_DIR)

    # Step 3 – Load raw XPT
    raw_df = load_brfss_xpt(xpt_path)

    # Step 4 – Process
    print("\nProcessing BRFSS variables …")
    processed_df = process_brfss(raw_df)

    print(f"\nProcessed dataset summary:")
    print(f"  Total rows:        {len(processed_df):>10,}")
    print(f"  Heart disease (1): {int(processed_df['HeartDisease'].sum()):>10,} "
          f"({processed_df['HeartDisease'].mean()*100:.1f}%)")
    print(f"\nAge group distribution:")
    age_bins = [0, 40, 55, 200]
    age_labels = ['Under 40', '40-55', 'Over 55']
    age_groups = pd.cut(processed_df['Age'], bins=age_bins, labels=age_labels,
                        right=False)
    print(age_groups.value_counts().sort_index().to_string())

    # Step 5 – Save
    print(f"\nSaving processed dataset to: {OUTPUT_CSV}")
    processed_df.to_csv(OUTPUT_CSV, index=False)
    print("Done.")
    print("\nYou can now run the full pipeline with:")
    print(f"  python pipeline.py --data {OUTPUT_CSV} --output results")


if __name__ == "__main__":
    main()
