"""
Model evaluation module for heart disease prediction.
Implements various evaluation metrics and bias analysis.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, roc_auc_score, precision_score, recall_score,
    confusion_matrix, classification_report, roc_curve
)
import matplotlib.pyplot as plt
import seaborn as sns


def calculate_metrics(y_true, y_pred, y_proba=None):
    """
    Calculate comprehensive evaluation metrics.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_proba: Predicted probabilities (optional)
        
    Returns:
        Dictionary of metrics
    """
    metrics = {}
    
    # Basic metrics
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
    
    # F1 score
    if metrics['precision'] + metrics['recall'] > 0:
        metrics['f1'] = 2 * (metrics['precision'] * metrics['recall']) / \
                       (metrics['precision'] + metrics['recall'])
    else:
        metrics['f1'] = 0
    
    # AUC-ROC (requires probabilities)
    if y_proba is not None:
        try:
            metrics['auc_roc'] = roc_auc_score(y_true, y_proba)
        except ValueError:
            # Can occur if only one class is present in y_true
            metrics['auc_roc'] = None
    
    # Confusion matrix
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    metrics['true_negative'] = tn
    metrics['false_positive'] = fp
    metrics['false_negative'] = fn
    metrics['true_positive'] = tp
    
    # False Negative Rate (FNR)
    if fn + tp > 0:
        metrics['false_negative_rate'] = fn / (fn + tp)
    else:
        metrics['false_negative_rate'] = 0
    
    # False Positive Rate (FPR)
    if fp + tn > 0:
        metrics['false_positive_rate'] = fp / (fp + tn)
    else:
        metrics['false_positive_rate'] = 0
    
    return metrics


def evaluate_model(model, X_test, y_test):
    """
    Evaluate a single model.
    
    Args:
        model: Trained model
        X_test: Test features
        y_test: Test labels
        
    Returns:
        Dictionary of metrics and predictions
    """
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Get probabilities if available
    y_proba = None
    if hasattr(model, 'predict_proba'):
        y_proba = model.predict_proba(X_test)[:, 1]
    
    # Calculate metrics
    metrics = calculate_metrics(y_test, y_pred, y_proba)
    
    return {
        'metrics': metrics,
        'y_pred': y_pred,
        'y_proba': y_proba
    }


def evaluate_by_age_group(model, X_test, y_test, age_groups):
    """
    Evaluate model performance for each age group.
    
    Args:
        model: Trained model
        X_test: Test features
        y_test: Test labels
        age_groups: Age group labels
        
    Returns:
        Dictionary with metrics for each age group
    """
    results = {}
    
    # Get predictions once
    y_pred = model.predict(X_test)
    y_proba = None
    if hasattr(model, 'predict_proba'):
        y_proba = model.predict_proba(X_test)[:, 1]
    
    # Evaluate for each age group
    for age_group in ['Under 40', '40-55', 'Over 55']:
        mask = age_groups == age_group
        
        if mask.sum() == 0:
            continue
        
        y_true_group = y_test[mask]
        y_pred_group = y_pred[mask]
        y_proba_group = y_proba[mask] if y_proba is not None else None
        
        metrics = calculate_metrics(y_true_group, y_pred_group, y_proba_group)
        metrics['sample_size'] = mask.sum()
        
        results[age_group] = metrics
    
    return results


def create_comparison_dataframe(age_group_results):
    """
    Create a DataFrame comparing metrics across age groups.
    
    Args:
        age_group_results: Dictionary with results for each age group
        
    Returns:
        DataFrame with comparison
    """
    rows = []
    
    for age_group, metrics in age_group_results.items():
        row = {
            'Age Group': age_group,
            'Sample Size': metrics.get('sample_size', 0),
            'Accuracy': metrics.get('accuracy', 0),
            'Precision': metrics.get('precision', 0),
            'Recall': metrics.get('recall', 0),
            'F1 Score': metrics.get('f1', 0),
            'AUC-ROC': metrics.get('auc_roc', 0),
            'False Negative Rate': metrics.get('false_negative_rate', 0),
            'False Positive Rate': metrics.get('false_positive_rate', 0)
        }
        rows.append(row)
    
    df = pd.DataFrame(rows)
    return df


def plot_confusion_matrix(y_true, y_pred, title='Confusion Matrix', save_path=None):
    """
    Plot confusion matrix.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        title: Plot title
        save_path: Path to save the plot
    """
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Disease', 'Disease'],
                yticklabels=['No Disease', 'Disease'])
    plt.title(title)
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path)
    plt.close()


def plot_age_group_comparison(comparison_df, metric='false_negative_rate', 
                              title=None, save_path=None):
    """
    Plot comparison of a metric across age groups.
    
    Args:
        comparison_df: DataFrame with age group comparisons
        metric: Metric to plot
        title: Plot title
        save_path: Path to save the plot
    """
    if title is None:
        title = f'{metric.replace("_", " ").title()} by Age Group'
    
    plt.figure(figsize=(10, 6))
    
    # Convert column name to match DataFrame
    metric_col = metric.replace('_', ' ').title()
    if metric_col not in comparison_df.columns:
        # Try alternative naming
        for col in comparison_df.columns:
            if col.lower().replace(' ', '_') == metric.lower():
                metric_col = col
                break
    
    plt.bar(comparison_df['Age Group'], comparison_df[metric_col])
    plt.title(title)
    plt.xlabel('Age Group')
    plt.ylabel(metric_col)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path)
    plt.close()


def plot_roc_curve(y_true, y_proba, title='ROC Curve', save_path=None):
    """
    Plot ROC curve.
    
    Args:
        y_true: True labels
        y_proba: Predicted probabilities
        title: Plot title
        save_path: Path to save the plot
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    auc = roc_auc_score(y_true, y_proba)
    
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, label=f'AUC = {auc:.3f}')
    plt.plot([0, 1], [0, 1], 'k--', label='Random')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path)
    plt.close()


def generate_report(model_name, overall_metrics, age_group_results):
    """
    Generate a text report of model performance.
    
    Args:
        model_name: Name of the model
        overall_metrics: Overall performance metrics
        age_group_results: Results by age group
        
    Returns:
        String report
    """
    report = f"\n{'='*60}\n"
    report += f"Model: {model_name}\n"
    report += f"{'='*60}\n\n"
    
    report += "Overall Performance:\n"
    report += f"  Accuracy:              {overall_metrics['accuracy']:.4f}\n"
    report += f"  Precision:             {overall_metrics['precision']:.4f}\n"
    report += f"  Recall:                {overall_metrics['recall']:.4f}\n"
    report += f"  F1 Score:              {overall_metrics['f1']:.4f}\n"
    if overall_metrics.get('auc_roc'):
        report += f"  AUC-ROC:               {overall_metrics['auc_roc']:.4f}\n"
    report += f"  False Negative Rate:   {overall_metrics['false_negative_rate']:.4f}\n"
    report += f"  False Positive Rate:   {overall_metrics['false_positive_rate']:.4f}\n\n"
    
    report += "Performance by Age Group:\n"
    comparison_df = create_comparison_dataframe(age_group_results)
    report += comparison_df.to_string(index=False)
    report += "\n\n"
    
    return report
