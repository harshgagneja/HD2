"""
Model training module for heart disease prediction.
Implements multiple ML models.
"""

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
import numpy as np


def train_logistic_regression(X_train, y_train, class_weight=None, random_state=42):
    """
    Train a Logistic Regression model.
    
    Args:
        X_train: Training features
        y_train: Training labels
        class_weight: Class weights for handling imbalanced data
        random_state: Random seed
        
    Returns:
        Trained model
    """
    model = LogisticRegression(
        max_iter=1000,
        class_weight=class_weight,
        random_state=random_state
    )
    model.fit(X_train, y_train)
    return model


def train_random_forest(X_train, y_train, class_weight=None, random_state=42):
    """
    Train a Random Forest model.
    
    Args:
        X_train: Training features
        y_train: Training labels
        class_weight: Class weights for handling imbalanced data
        random_state: Random seed
        
    Returns:
        Trained model
    """
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        class_weight=class_weight,
        random_state=random_state,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    return model


def calculate_scale_pos_weight(y_train):
    """
    Calculate scale_pos_weight for XGBoost from training labels.
    
    Args:
        y_train: Training labels
        
    Returns:
        Scale pos weight ratio
    """
    neg_count = (y_train == 0).sum()
    pos_count = (y_train == 1).sum()
    return neg_count / pos_count if pos_count > 0 else 1.0


def train_xgboost(X_train, y_train, scale_pos_weight=None, random_state=42):
    """
    Train an XGBoost model.
    
    Args:
        X_train: Training features
        y_train: Training labels
        scale_pos_weight: Weight for positive class (for handling imbalanced data)
        random_state: Random seed
        
    Returns:
        Trained model
    """
    params = {
        'n_estimators': 100,
        'max_depth': 6,
        'learning_rate': 0.1,
        'random_state': random_state,
        'n_jobs': -1
    }
    
    if scale_pos_weight is not None:
        params['scale_pos_weight'] = scale_pos_weight
    
    model = XGBClassifier(**params)
    model.fit(X_train, y_train)
    return model


def train_svm(X_train, y_train, class_weight=None, random_state=42):
    """
    Train an SVM model.
    
    Args:
        X_train: Training features
        y_train: Training labels
        class_weight: Class weights for handling imbalanced data
        random_state: Random seed
        
    Returns:
        Trained model
    """
    model = SVC(
        kernel='rbf',
        probability=True,
        class_weight=class_weight,
        random_state=random_state
    )
    model.fit(X_train, y_train)
    return model


def train_all_models(X_train, y_train, class_weight=None, random_state=42):
    """
    Train all models.
    
    Args:
        X_train: Training features
        y_train: Training labels
        class_weight: Class weights for handling imbalanced data
        random_state: Random seed
        
    Returns:
        Dictionary of trained models
    """
    models = {}
    
    print("Training Logistic Regression...")
    models['Logistic Regression'] = train_logistic_regression(
        X_train, y_train, class_weight, random_state
    )
    
    print("Training Random Forest...")
    models['Random Forest'] = train_random_forest(
        X_train, y_train, class_weight, random_state
    )
    
    print("Training XGBoost...")
    # Calculate scale_pos_weight for XGBoost if using balanced weighting
    scale_pos_weight = None
    if class_weight == 'balanced':
        scale_pos_weight = calculate_scale_pos_weight(y_train)
    
    models['XGBoost'] = train_xgboost(
        X_train, y_train, scale_pos_weight, random_state
    )
    
    print("Training SVM...")
    models['SVM'] = train_svm(
        X_train, y_train, class_weight, random_state
    )
    
    return models


def adjust_threshold(model, X, threshold=0.5):
    """
    Adjust prediction threshold for binary classification.
    
    Args:
        model: Trained model with predict_proba method
        X: Features
        threshold: Classification threshold
        
    Returns:
        Binary predictions
    """
    probas = model.predict_proba(X)[:, 1]
    predictions = (probas >= threshold).astype(int)
    return predictions


def find_optimal_threshold(model, X_val, y_val, metric='f1'):
    """
    Find optimal threshold to maximize a given metric.
    
    Args:
        model: Trained model
        X_val: Validation features
        y_val: Validation labels
        metric: Metric to optimize ('f1', 'recall', 'precision')
        
    Returns:
        Optimal threshold
    """
    from sklearn.metrics import f1_score, recall_score, precision_score
    
    probas = model.predict_proba(X_val)[:, 1]
    thresholds = np.arange(0.1, 0.9, 0.01)
    
    best_score = 0
    best_threshold = 0.5
    
    for threshold in thresholds:
        predictions = (probas >= threshold).astype(int)
        
        if metric == 'f1':
            score = f1_score(y_val, predictions)
        elif metric == 'recall':
            score = recall_score(y_val, predictions)
        elif metric == 'precision':
            score = precision_score(y_val, predictions)
        else:
            raise ValueError(f"Unknown metric: {metric}")
        
        if score > best_score:
            best_score = score
            best_threshold = threshold
    
    return best_threshold
