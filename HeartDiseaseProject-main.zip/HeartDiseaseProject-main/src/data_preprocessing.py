"""
Data preprocessing module for heart disease prediction.
Handles data loading, cleaning, and preparation.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def load_data(filepath):
    """
    Load the BRFSS dataset.
    
    Args:
        filepath: Path to the CSV file
        
    Returns:
        DataFrame with the loaded data
    """
    df = pd.read_csv(filepath)
    return df


def create_age_groups(df, age_column='Age'):
    """
    Create age group categories.
    
    Args:
        df: Input DataFrame
        age_column: Name of the age column
        
    Returns:
        DataFrame with added 'AgeGroup' column
    """
    df = df.copy()
    
    def categorize_age(age):
        if age < 40:
            return 'Under 40'
        elif age <= 55:
            return '40-55'
        else:
            return 'Over 55'
    
    df['AgeGroup'] = df[age_column].apply(categorize_age)
    return df


def clean_data(df):
    """
    Clean the dataset by handling missing values and invalid data.
    
    Args:
        df: Input DataFrame
        
    Returns:
        Cleaned DataFrame
    """
    df = df.copy()
    
    # Remove rows with missing target variable
    if 'HeartDisease' in df.columns:
        df = df.dropna(subset=['HeartDisease'])
    
    # Handle missing values in features
    # For numerical columns, fill with median
    numerical_cols = df.select_dtypes(include=[np.number]).columns
    for col in numerical_cols:
        if df[col].isnull().sum() > 0:
            df[col] = df[col].fillna(df[col].median())
    
    # For categorical columns, fill with mode
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        if df[col].isnull().sum() > 0:
            df[col] = df[col].fillna(df[col].mode()[0])
    
    return df


def encode_categorical_features(df, target_column='HeartDisease'):
    """
    Convert categorical features to numerical form.
    
    Args:
        df: Input DataFrame
        target_column: Name of the target column to exclude from encoding
        
    Returns:
        DataFrame with encoded features
    """
    df = df.copy()
    
    # Get categorical columns (excluding target and AgeGroup)
    categorical_cols = df.select_dtypes(include=['object']).columns
    categorical_cols = [col for col in categorical_cols if col not in [target_column, 'AgeGroup']]
    
    # Apply one-hot encoding
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
    
    return df


def prepare_features_target(df, target_column='HeartDisease', exclude_cols=None):
    """
    Separate features and target variable.
    
    Args:
        df: Input DataFrame
        target_column: Name of the target column
        exclude_cols: List of columns to exclude from features
        
    Returns:
        X (features), y (target), feature_names
    """
    if exclude_cols is None:
        exclude_cols = ['AgeGroup']
    
    # Separate target
    y = df[target_column]
    
    # Separate features
    feature_cols = [col for col in df.columns if col not in [target_column] + exclude_cols]
    X = df[feature_cols]
    
    return X, y, feature_cols


def split_data(X, y, test_size=0.2, random_state=42):
    """
    Split data into training and testing sets.
    
    Args:
        X: Features
        y: Target
        test_size: Proportion of test set
        random_state: Random seed
        
    Returns:
        X_train, X_test, y_train, y_test
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return X_train, X_test, y_train, y_test


def scale_features(X_train, X_test):
    """
    Scale features using StandardScaler.
    
    Args:
        X_train: Training features
        X_test: Testing features
        
    Returns:
        Scaled X_train, X_test, and the scaler object
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, scaler


def preprocess_pipeline(filepath, target_column='HeartDisease', age_column='Age', 
                       test_size=0.2, random_state=42, scale=True):
    """
    Complete preprocessing pipeline.
    
    Args:
        filepath: Path to the CSV file
        target_column: Name of the target column
        age_column: Name of the age column
        test_size: Proportion of test set
        random_state: Random seed
        scale: Whether to scale features
        
    Returns:
        Dictionary containing processed data and metadata
    """
    # Load data
    df = load_data(filepath)
    
    # Create age groups
    df = create_age_groups(df, age_column)
    
    # Clean data
    df = clean_data(df)
    
    # Encode categorical features
    df = encode_categorical_features(df, target_column)
    
    # Prepare features and target
    X, y, feature_names = prepare_features_target(df, target_column)
    
    # Keep age groups for later analysis
    age_groups = df['AgeGroup']
    
    # Split data
    X_train, X_test, y_train, y_test = split_data(X, y, test_size, random_state)
    
    # Get corresponding age groups for train and test
    age_groups_train = age_groups.loc[X_train.index]
    age_groups_test = age_groups.loc[X_test.index]
    
    # Reset indices
    X_train = X_train.reset_index(drop=True)
    X_test = X_test.reset_index(drop=True)
    y_train = y_train.reset_index(drop=True)
    y_test = y_test.reset_index(drop=True)
    age_groups_train = age_groups_train.reset_index(drop=True)
    age_groups_test = age_groups_test.reset_index(drop=True)
    
    # Scale features if requested
    scaler = None
    if scale:
        X_train, X_test, scaler = scale_features(X_train, X_test)
        X_train = pd.DataFrame(X_train, columns=feature_names)
        X_test = pd.DataFrame(X_test, columns=feature_names)
    
    return {
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
        'age_groups_train': age_groups_train,
        'age_groups_test': age_groups_test,
        'feature_names': feature_names,
        'scaler': scaler
    }
