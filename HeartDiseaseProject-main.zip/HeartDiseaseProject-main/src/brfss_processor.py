"""
BRFSS 2024 data processor for the Heart Disease Prediction project.

Maps raw CDC BRFSS (Behavioral Risk Factor Surveillance System) XPT variables
to the column format expected by the project's preprocessing pipeline.

Key BRFSS 2024 variable mappings used:
    _AGE80      → Age           (imputed age value, capped at 80)
    CVDCRHD4    → HeartDisease  (coronary heart disease diagnosis)
    SEXVAR      → Gender
    _BMI5       → BMI           (computed BMI * 100; divided by 100 here)
    _SMOKER3    → Smoking
    EXERANY2    → PhysicalActivity
    DRNKANY5    → AlcoholUse    (combined with _RFDRHV7 for Heavy/Moderate)
    DIABETE4    → Diabetes
    BPHIGH6     → HighBloodPressure
    TOLDHI3     → HighCholesterol
"""

import pandas as pd
import numpy as np


# BRFSS source columns required for processing
REQUIRED_BRFSS_COLUMNS = [
    '_AGE80',
    'CVDCRHD4',
    'SEXVAR',
    '_BMI5',
    '_SMOKER3',
    'EXERANY2',
    'DRNKANY5',
    '_RFDRHV7',
    'DIABETE4',
    'BPHIGH6',
    'TOLDHI3',
]


def _map_heart_disease(series):
    """
    CVDCRHD4: Ever told had coronary heart disease?
    1=Yes, 2=No, 7=Don't know, 9=Refused → drop 7/9/NaN
    """
    mapped = series.replace({1: 1, 2: 0})
    mapped = mapped.where(mapped.isin([0, 1]))
    return mapped


def _map_age(series):
    """
    _AGE80: Imputed age value (18–80, where 80 = 80 or older).
    Values of 7 (don't know/refused) are treated as missing and dropped.
    """
    age = pd.to_numeric(series, errors='coerce')
    age = age.where((age >= 18) & (age <= 80))
    return age


def _map_gender(series):
    """
    SEXVAR: Sex of respondent.
    1=Male, 2=Female
    """
    return series.map({1: 'Male', 2: 'Female'})


def _map_bmi(series):
    """
    _BMI5: Computed BMI * 100.
    Values >= 9999 are missing. Divide by 100 for actual BMI.
    """
    bmi = pd.to_numeric(series, errors='coerce')
    bmi = bmi.where(bmi < 9900)
    return bmi / 100.0


def _map_smoking(series):
    """
    _SMOKER3: Computed smoking status.
    1=Current (every day), 2=Current (some days) → 'Current'
    3=Former → 'Former'
    4=Never → 'Never'
    9=Don't know/Refused → NaN (dropped)
    """
    return series.map({1: 'Current', 2: 'Current', 3: 'Former', 4: 'Never'})


def _map_physical_activity(series):
    """
    EXERANY2: Exercise/physical activity in past 30 days.
    1=Yes, 2=No, 7=Don't know, 9=Refused → drop 7/9/NaN
    """
    return series.map({1: 'Yes', 2: 'No'})


def _map_alcohol(drnkany5, rfdrhv7):
    """
    Combine DRNKANY5 (any drinking) and _RFDRHV7 (heavy drinker) to produce
    three-level AlcoholUse: 'None', 'Moderate', or 'Heavy'.

    DRNKANY5: 1=Yes, 2=No
    _RFDRHV7: 1=No (not heavy), 2=Yes (heavy)
    """
    alcohol = pd.Series(np.nan, index=drnkany5.index, dtype=object)
    # No alcohol
    alcohol = alcohol.where(drnkany5 != 2, 'None')
    # Drinker – check heavy flag
    is_drinker = drnkany5 == 1
    is_heavy = rfdrhv7 == 2
    alcohol = alcohol.where(~(is_drinker & is_heavy), 'Heavy')
    alcohol = alcohol.where(~(is_drinker & ~is_heavy), 'Moderate')
    return alcohol


def _map_diabetes(series):
    """
    DIABETE4: Diabetes status.
    1=Yes → 'Yes'
    2=Yes (pregnancy only), 3=No, 4=Borderline → 'No'
    7=Don't know, 9=Refused → NaN (dropped)
    """
    return series.map({1: 'Yes', 2: 'No', 3: 'No', 4: 'No'})


def _map_blood_pressure(series):
    """
    BPHIGH6: Ever told blood pressure high.
    1=Yes → 'Yes'
    2=Yes (pregnancy only), 3=No, 4=Borderline → 'No'
    7=Don't know, 9=Refused → NaN (dropped)
    """
    return series.map({1: 'Yes', 2: 'No', 3: 'No', 4: 'No'})


def _map_cholesterol(series):
    """
    TOLDHI3: Ever told blood cholesterol high.
    1=Yes → 'Yes'
    2=No → 'No'
    7=Don't know, 9=Refused → NaN (dropped)
    """
    return series.map({1: 'Yes', 2: 'No'})


def process_brfss(df):
    """
    Transform a raw BRFSS DataFrame into the format expected by the project.

    Args:
        df: Raw BRFSS DataFrame loaded from the XPT file.

    Returns:
        Processed DataFrame with columns:
            Age, Gender, BMI, Smoking, PhysicalActivity, AlcoholUse,
            Diabetes, HighBloodPressure, HighCholesterol, HeartDisease

    Raises:
        KeyError: If any required BRFSS column is missing from ``df``.
    """
    # Normalise column names to upper-case to handle any case variations
    df = df.copy()
    df.columns = [c.upper() for c in df.columns]

    missing = [c for c in REQUIRED_BRFSS_COLUMNS if c not in df.columns]
    if missing:
        raise KeyError(
            f"The following required BRFSS columns are missing: {missing}. "
            "Ensure you are using the full BRFSS landline+cell (LLCP) dataset."
        )

    out = pd.DataFrame()
    out['Age'] = _map_age(df['_AGE80'])
    out['Gender'] = _map_gender(df['SEXVAR'])
    out['BMI'] = _map_bmi(df['_BMI5'])
    out['Smoking'] = _map_smoking(df['_SMOKER3'])
    out['PhysicalActivity'] = _map_physical_activity(df['EXERANY2'])
    out['AlcoholUse'] = _map_alcohol(df['DRNKANY5'], df['_RFDRHV7'])
    out['Diabetes'] = _map_diabetes(df['DIABETE4'])
    out['HighBloodPressure'] = _map_blood_pressure(df['BPHIGH6'])
    out['HighCholesterol'] = _map_cholesterol(df['TOLDHI3'])
    out['HeartDisease'] = _map_heart_disease(df['CVDCRHD4'])

    # Drop rows where the target or age is missing
    out = out.dropna(subset=['HeartDisease', 'Age'])

    # Reset index after row removal
    out = out.reset_index(drop=True)

    return out


def load_brfss_xpt(xpt_path):
    """
    Load a BRFSS XPT (SAS transport) file into a DataFrame.

    Args:
        xpt_path: Path to the ``.xpt`` file on disk.

    Returns:
        Raw DataFrame as loaded from the XPT file.
    """
    print(f"Loading BRFSS XPT file: {xpt_path}")
    print("(This may take a minute – the file is large.)")
    df = pd.read_sas(xpt_path, format='xport', encoding='latin-1')
    print(f"Loaded {len(df):,} rows and {len(df.columns)} columns.")
    return df
