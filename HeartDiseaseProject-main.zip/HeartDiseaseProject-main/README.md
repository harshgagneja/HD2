# Heart Disease Prediction: Age Group Bias Analysis

## Project Overview

This project investigates whether machine learning models for heart disease prediction perform worse for younger patients compared to older patients, even when overall accuracy appears high.

### Research Questions

1. **Do machine learning models predict heart disease equally well for all age groups?**
2. **Are younger individuals more likely to be misclassified as low risk?**
3. **Can simple adjustments improve model performance for younger patients without greatly reducing overall accuracy?**

### Team Members
- Hershey Gagneja
- Sean DeFrank
- Christine Sulio

## Problem Statement

Machine learning models are often used to predict whether someone has heart disease. These models usually report one overall accuracy score, which makes them seem reliable. However, this overall score may hide problems in how the model performs for different age groups.

Younger patients are less common in heart disease datasets, which means models may not learn their patterns as well. As a result, the model could incorrectly predict that a younger person does not have heart disease when they actually do. This type of error is especially concerning because it can delay early detection and treatment.

## Dataset

We use the CDC Behavioral Risk Factor Surveillance System (BRFSS) dataset (or a synthetic version for demonstration).

- **Number of data points:** Over 400,000 (original) or 10,000 (sample)
- **Features:** Age, gender, BMI, smoking status, physical activity, alcohol use, diabetes, blood pressure, cholesterol, and other health-related factors
- **Target variable:** Whether an individual has been diagnosed with heart disease

### BRFSS 2024 Real Data

The project includes a script to automatically download and process the official **CDC BRFSS 2024** dataset. See [Using Real BRFSS 2024 Data](#using-real-brfss-2024-data) for instructions.

## Age Groups

We analyze performance across three age groups:
- **Under 40**
- **40-55**
- **Over 55**

## Models

We implement and evaluate four machine learning models:
1. **Logistic Regression**
2. **Random Forest**
3. **XGBoost**
4. **Support Vector Machine (SVM)**

## Evaluation Metrics

- **Accuracy:** Overall correctness
- **AUC-ROC:** Area under the ROC curve
- **Precision and Recall:** For positive class (heart disease)
- **False Negative Rate (FNR):** Proportion of actual disease cases missed
- **Confusion matrices:** For each age group

## Bias Mitigation Techniques

To address potential age-related bias, we implement:
1. **Class reweighting:** Adjusting class weights to handle imbalanced data
2. **Threshold adjustment:** Modifying decision thresholds to optimize for specific metrics

## Using Real BRFSS 2024 Data

The `fetch_brfss_data.py` script downloads the official CDC BRFSS 2024 combined landline and cell dataset (~200 MB compressed), extracts it, maps the raw survey variables to the project's column format, and saves the result as `data/brfss_2024.csv`.

```bash
python fetch_brfss_data.py
```

The script handles the following BRFSS 2024 variable mappings automatically:

| BRFSS Column  | Project Column    | Description                           |
|---------------|-------------------|---------------------------------------|
| `_AGE80`      | `Age`             | Imputed age value (18–80)             |
| `CVDCRHD4`    | `HeartDisease`    | Coronary heart disease diagnosis      |
| `SEXVAR`      | `Gender`          | Sex of respondent                     |
| `_BMI5`       | `BMI`             | Computed BMI (÷ 100)                  |
| `_SMOKER3`    | `Smoking`         | Smoking status                        |
| `EXERANY2`    | `PhysicalActivity`| Exercise in past 30 days              |
| `DRNKANY5` + `_RFDRHV7` | `AlcoholUse` | Alcohol use level (None/Moderate/Heavy) |
| `DIABETE4`    | `Diabetes`        | Diabetes diagnosis                    |
| `BPHIGH6`     | `HighBloodPressure` | High blood pressure diagnosis       |
| `TOLDHI3`     | `HighCholesterol` | High cholesterol diagnosis            |

Once the data is downloaded and processed, run the full pipeline on it:

```bash
python pipeline.py --data data/brfss_2024.csv --output results
```

The raw BRFSS processor is available in `src/brfss_processor.py` if you want to use it independently:

```python
from src.brfss_processor import load_brfss_xpt, process_brfss

raw_df = load_brfss_xpt("data/LLCP2024.XPT")
processed_df = process_brfss(raw_df)
processed_df.to_csv("data/brfss_2024.csv", index=False)
```

## Project Structure

```
HeartDiseaseProject/
├── data/                           # Data directory
│   ├── heart_disease_sample.csv   # Sample dataset (synthetic)
│   └── brfss_2024.csv             # Real BRFSS 2024 data (after running fetch_brfss_data.py)
├── src/                            # Source code
│   ├── __init__.py
│   ├── data_preprocessing.py      # Data loading and preprocessing
│   ├── model_training.py          # Model training functions
│   ├── evaluation.py              # Evaluation metrics and visualization
│   └── brfss_processor.py         # BRFSS 2024 variable mapping
├── notebooks/                      # Jupyter notebooks
│   └── heart_disease_analysis.ipynb  # Interactive analysis
├── results/                        # Output directory for results
├── models/                         # Saved models (optional)
├── pipeline.py                     # Main pipeline script
├── fetch_brfss_data.py            # Download and process BRFSS 2024 data
├── generate_sample_data.py        # Sample data generator
├── requirements.txt               # Python dependencies
└── README.md                      # This file
```

## Installation

1. Clone the repository:
```bash
git clone https://github.com/harshgagneja/HeartDiseaseProject.git
cd HeartDiseaseProject
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Generate Sample Data

To create a synthetic dataset for testing:

```bash
python generate_sample_data.py
```

This will create `data/heart_disease_sample.csv` with 10,000 samples.

### Run the Complete Pipeline

To run the entire analysis pipeline:

```bash
python pipeline.py --data data/heart_disease_sample.csv --output results
```

Options:
- `--data`: Path to the input CSV file (required)
- `--output`: Directory to save results (default: `results`)
- `--seed`: Random seed for reproducibility (default: 42)

### Interactive Analysis

For interactive exploration, use the Jupyter notebook:

```bash
cd notebooks
jupyter notebook heart_disease_analysis.ipynb
```

## Expected Results

We expect to find that:
1. **Models achieve strong overall accuracy** across the dataset
2. **Performance for younger patients is worse**, especially in recall and false negative rate
3. **Simple adjustments can reduce these gaps** with minimal impact on overall performance

## Output

The pipeline generates:

1. **Reports** (`.txt` files): Detailed performance metrics for each model
2. **CSV files**: Age group comparisons and summary statistics
3. **Visualizations** (`.png` files):
   - Confusion matrices
   - ROC curves
   - False Negative Rate by age group
   - Comparison plots (baseline vs. weighted)

All outputs are saved in the `results/` directory.

## Key Findings

After running the pipeline, examine:

1. **False Negative Rate (FNR) by Age Group**: Check if younger patients have higher FNR
2. **Recall Comparison**: Compare recall scores across age groups
3. **Impact of Bias Mitigation**: Evaluate whether class reweighting improves performance for younger patients

## Importance

Heart disease is often overlooked in younger individuals. If machine learning models also struggle to identify risk in this group, it could lead to delayed diagnosis. This project highlights why subgroup analysis is important and shows how relying only on overall accuracy can be misleading in medical machine learning.

## Limitations

- Sample size for younger patients may be limited
- Synthetic data may not capture all real-world patterns
- Model performance depends on feature quality and availability
- Bias mitigation techniques may have trade-offs between metrics

## Future Work

- Incorporate additional features (e.g., family history, stress levels)
- Explore advanced bias mitigation techniques (e.g., fairness constraints)
- Validate findings on real-world clinical data using `fetch_brfss_data.py`
- Develop age-specific models or ensemble approaches

## License

This project is for educational purposes.

## References

- CDC Behavioral Risk Factor Surveillance System (BRFSS): https://www.cdc.gov/brfss/
- Fairness in Machine Learning: https://fairmlbook.org/

## Contact

For questions or feedback, please open an issue on GitHub.