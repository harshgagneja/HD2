"""
Generate sample heart disease dataset for testing.
This creates a synthetic dataset similar to the BRFSS format.
"""

import pandas as pd
import numpy as np


def generate_sample_data(n_samples=10000, random_state=42):
    """
    Generate synthetic heart disease dataset.
    
    Args:
        n_samples: Number of samples to generate
        random_state: Random seed
        
    Returns:
        DataFrame with synthetic data
    """
    np.random.seed(random_state)
    
    # Age distribution (more older patients)
    age = np.random.choice(
        [25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80],
        size=n_samples,
        p=[0.03, 0.04, 0.05, 0.08, 0.10, 0.12, 0.14, 0.15, 0.12, 0.09, 0.05, 0.03]
    )
    
    # Gender
    gender = np.random.choice(['Male', 'Female'], size=n_samples)
    
    # BMI
    bmi = np.random.normal(28, 6, n_samples)
    bmi = np.clip(bmi, 15, 50)
    
    # Smoking status
    smoking = np.random.choice(['Never', 'Former', 'Current'], size=n_samples,
                              p=[0.5, 0.3, 0.2])
    
    # Physical activity
    physical_activity = np.random.choice(['Yes', 'No'], size=n_samples, p=[0.6, 0.4])
    
    # Alcohol use
    alcohol_use = np.random.choice(['None', 'Moderate', 'Heavy'], size=n_samples,
                                  p=[0.3, 0.5, 0.2])
    
    # Diabetes
    diabetes_prob = (age / 100) + 0.1
    diabetes = np.random.binomial(1, diabetes_prob)
    diabetes = np.where(diabetes == 1, 'Yes', 'No')
    
    # High blood pressure
    bp_prob = (age / 100) + 0.15
    high_bp = np.random.binomial(1, bp_prob)
    high_bp = np.where(high_bp == 1, 'Yes', 'No')
    
    # High cholesterol
    chol_prob = (age / 100) + 0.2
    high_chol = np.random.binomial(1, chol_prob)
    high_chol = np.where(high_chol == 1, 'Yes', 'No')
    
    # Heart disease (target variable)
    # Probability increases with age and risk factors
    base_prob = age / 200
    
    # Adjust for risk factors
    risk_score = base_prob.copy()
    risk_score += 0.1 * (diabetes == 'Yes')
    risk_score += 0.15 * (high_bp == 'Yes')
    risk_score += 0.1 * (high_chol == 'Yes')
    risk_score += 0.05 * (smoking == 'Current')
    risk_score += 0.03 * (smoking == 'Former')
    risk_score += 0.05 * (bmi > 30)
    risk_score -= 0.05 * (physical_activity == 'Yes')
    
    # Younger patients have lower probability (creating bias)
    risk_score = np.where(age < 40, risk_score * 0.3, risk_score)
    
    risk_score = np.clip(risk_score, 0, 0.5)
    
    heart_disease = np.random.binomial(1, risk_score)
    
    # Create DataFrame
    df = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI': bmi,
        'Smoking': smoking,
        'PhysicalActivity': physical_activity,
        'AlcoholUse': alcohol_use,
        'Diabetes': diabetes,
        'HighBloodPressure': high_bp,
        'HighCholesterol': high_chol,
        'HeartDisease': heart_disease
    })
    
    return df


if __name__ == '__main__':
    # Generate sample data
    print("Generating sample heart disease dataset...")
    df = generate_sample_data(n_samples=10000, random_state=42)
    
    # Save to CSV
    output_path = 'data/heart_disease_sample.csv'
    df.to_csv(output_path, index=False)
    
    print(f"Sample data saved to {output_path}")
    print(f"\nDataset info:")
    print(f"  Total samples: {len(df)}")
    print(f"  Heart disease cases: {df['HeartDisease'].sum()} ({df['HeartDisease'].mean()*100:.1f}%)")
    print(f"\nAge distribution:")
    print(df['Age'].describe())
    print(f"\nClass distribution:")
    print(df['HeartDisease'].value_counts())
